if (strcmp(argument, "adglehmer") == 0) x = 0;
else if (strcmp(argument, "annem") == 0) x = 1; // This one has nasal infix!
else if (strcmp(argument, "aurdhenkal") == 0) x = 0;
else if (strcmp(argument, "bfwendwan") == 0) x = 0;
else if (strcmp(argument, "circumven") == 0) x = 0;
else if (strcmp(argument, "contraven") == 0) x = 0;
else if (strcmp(argument, "demneh") == 0) x = 0;
else if (strcmp(argument, "deten") == 0) x = 0;
else if (strcmp(argument, "diemmen") == 0) x = 1; // This one has nasal infix!
else if (strcmp(argument, "emerg") == 0) x = 0;
else if (strcmp(argument, "endermerg") == 0) x = 0;
else if (strcmp(argument, "exgventer") == 0) x = 0;
else if (strcmp(argument, "forglehmer") == 0) x = 0;
else if (strcmp(argument, "forgleimer") == 0) x = 0;
else if (strcmp(argument, "fwenschaw") == 0) x = 0;
else if (strcmp(argument, "glehmer") == 0) x = 0;
else if (strcmp(argument, "greumel") == 0) x = 0;
else if (strcmp(argument, "gwenman") == 0) x = 0;
else if (strcmp(argument, "hensel") == 0) x = 0;
else if (strcmp(argument, "interven") == 0) x = 0;
else if (strcmp(argument, "kwenchau") == 0) x = 0;
else if (strcmp(argument, "menay") == 0) x = 0;
else if (strcmp(argument, "mercat") == 0) x = 0; // I know it's not a verb, but if someone try to conjuge it...
else if (strcmp(argument, "negleg") == 0) x = 0;
else if (strcmp(argument, "obten") == 0) x = 0;
else if (strcmp(argument, "preven") == 0) x = 0;
else if (strcmp(argument, "rembeurs") == 0) x = 0;
else if (strcmp(argument, "ressenteih") == 0) x = 0;
else if (strcmp(argument, "smeu") == 0) x = 0;
else if (strcmp(argument, "submerg") == 0) x = 0;
else if (strcmp(argument, "subven") == 0) x = 0;
