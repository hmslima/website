#ifndef CASES_H
#define CASES_H

void cases (short int lang);

#endif
