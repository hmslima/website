#ifndef SMALL_FUNCTIONS_H
#define SMALL_FUNCTIONS_H

short int checklang (char argument[192]);
void remove_capital_letters (char argument[192]);

#endif
