if (strcmp(argument, "abghend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "abgEnd");
}
else if (strcmp(argument, "abghends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "abgEnds");
}
else if (strcmp(argument, "abject") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "abjEkt");
}
else if (strcmp(argument, "absect") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "abzEkt");
}
else if (strcmp(argument, "absent") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "absEnt");
}
else if (strcmp(argument, "absents") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "absEnts");
}
else if (strcmp(argument, "addic") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "addIk");
}
else if (strcmp(argument, "adhes") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "adhEs");
}
else if (strcmp(argument, "affec") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "affEk");
}
else if (strcmp(argument, "affecs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "affEks");
}
else if (strcmp(argument, "aflig") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "aflIg");
}
else if (strcmp(argument, "africa") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "Afrika");
}
else if ((strcmp(argument, "AIDS") == 0) || (strcmp(argument, "aids") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "" SMALL_A_DIAERESIS_IN_TEXT "dz");
}
else if ((strcmp(argument, "Al-Gaddafi") == 0) || (strcmp(argument, "al-gaddafi") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "al gadAfi");
}
else if ((strcmp(argument, "Al-Khawarizmi") == 0) || (strcmp(argument, "al-khawarizmi") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "al qawarIdzmi");
}
else if (strcmp(argument, "aleg") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "alEg");
}
else if (strcmp(argument, "america") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "amErika");
}
else if (strcmp(argument, "apocryph") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "apokr" CAPITAL_U_DIAERESIS_IN_TEXT "f");
}
else if (strcmp(argument, "argument") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "arg" CAPITAL_U_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "argumentS") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "arg" CAPITAL_U_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nts");
}
else if (strcmp(argument, "arrest") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "arrEst");
}
else if ((strcmp(argument, "as-Sadat") == 0) || (strcmp(argument, "as-sadat") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "as sadAt");
}
else if (strcmp(argument, "ascend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "asEnd");
}
else if (strcmp(argument, "asperg") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "aspErg");
}
else if (strcmp(argument, "assist") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "asIst");
}
else if (strcmp(argument, "at-alamat") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "at alamAt");
}
else if (strcmp(argument, "b") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "be");
}
else if (strcmp(argument, "back-end") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "bak-end");
}
else if (strcmp(argument, "bain-marie") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_A_DIAERESIS_IN_TEXT "n marI");
}
else if (strcmp(argument, "bayghtiwent") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "bAygtiw" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "becep") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "tsEp");
}
else if (strcmp(argument, "beceps") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "tsEps");
}
else if ((strcmp(argument, "Belle-Epoque") == 0) || (strcmp(argument, "belle-epoque") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "bel epOk");
}
else if (strcmp(argument, "befrect") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "frEkt");
}
else if (strcmp(argument, "befrects") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "frEkts");
}
else if (strcmp(argument, "beghsses") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "gsEs");
}
else if ((strcmp(argument, "Bellzebub") == 0) || (strcmp(argument, "bellzebub") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "beldz" SMALL_E_DIAERESIS_IN_TEXT "bUb");
}
else if (strcmp(argument, "bemild") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "mIld");
}
else if (strcmp(argument, "bemilds") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "mIlds");
}
else if (strcmp(argument, "bepelp") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "pElp");
}
else if (strcmp(argument, "bepelps") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "pElps");
}
else if (strcmp(argument, "berdvisch") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "bErdvic");
}
else if (strcmp(argument, "berect") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "rEkt");
}
else if ((strcmp(argument, "Bergwntia") == 0) || (strcmp(argument, "bergwntia") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "bErguntya");
}
else if (strcmp(argument, "beryllium") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "r" CAPITAL_U_DIAERESIS_IN_TEXT "lyum");
}
else if ((strcmp(argument, "Bethsayda") == 0) || (strcmp(argument, "bethsayda") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "tsAyda");
}
else if (strcmp(argument, "beursindex") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" CAPITAL_O_DIAERESIS_IN_TEXT "rsind" SMALL_E_DIAERESIS_IN_TEXT "ks");
}
else if (strcmp(argument, "bevid") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "b" SMALL_E_DIAERESIS_IN_TEXT "vId");
}
else if (strcmp(argument, "bi-sabab") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "bi sabAb");
}
else if ((strcmp(argument, "Bingen") == 0) || (strcmp(argument, "bingen") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "bIng" SMALL_E_DIAERESIS_IN_TEXT "n");
}
else if ((strcmp(argument, "BIP") == 0) || (strcmp(argument, "bip") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "be i pe");
}
else if (strcmp(argument, "c") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "tse");
}
else if (strcmp(argument, "circumven") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "tsirkumvEn");
}
else if (strcmp(argument, "circumvens") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "tsirkumvEns");
}
else if (strcmp(argument, "comprehend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kompr" SMALL_E_DIAERESIS_IN_TEXT "hEnd");
}
else if (strcmp(argument, "comprehends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kompr" SMALL_E_DIAERESIS_IN_TEXT "hEnds");
}
else if (strcmp(argument, "concept") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kon(t)sEpt");
}
else if (strcmp(argument, "concepts") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kon(t)sEpts");
}
else if (strcmp(argument, "concern") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kontsErn");
}
else if (strcmp(argument, "concerns") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kontsErns");
}
else if (strcmp(argument, "conclus") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "konklUs");
}
else if (strcmp(argument, "concil") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kontsIl");
}
else if (strcmp(argument, "concils") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kontsIls");
}
else if (strcmp(argument, "confer") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "konfEr");
}
else if (strcmp(argument, "confers") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "konfErs");
}
else if (strcmp(argument, "conflict") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "konflIkt");
}
else if (strcmp(argument, "conflicts") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "konflIkts");
}
else if (strcmp(argument, "contradic") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kontradIk");
}
else if (strcmp(argument, "contradics") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kontradIks");
}
else if (strcmp(argument, "contraven") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kontravEn");
}
else if (strcmp(argument, "contravens") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kontravEns");
}
else if (strcmp(argument, "crossing-over") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "krOsing Ov" SMALL_E_DIAERESIS_IN_TEXT "r");
}
else if (strcmp(argument, "d") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "de");
}
else if (strcmp(argument, "dakruwent") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dAkr" SMALL_U_DIAERESIS_IN_TEXT "w" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "decent") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "tsEnt");
}
else if (strcmp(argument, "decret") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "krEt");
}
else if (strcmp(argument, "decrets") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "krEts");
}
else if (strcmp(argument, "defend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "fEnd");
}
else if (strcmp(argument, "defends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "fEnds");
}
else if (strcmp(argument, "defer") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "fEr");
}
else if (strcmp(argument, "defers") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "fErs");
}
else if (strcmp(argument, "dement") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "mEnt");
}
else if (strcmp(argument, "dements") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "mEnts");
}
else if (strcmp(argument, "denoument") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "nU:m" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "denouments") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "nU:m" SMALL_E_DIAERESIS_IN_TEXT "nts");
}
else if (strcmp(argument, "depend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "pEnd");
}
else if (strcmp(argument, "depends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "pEnds");
}
else if (strcmp(argument, "derid") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "rId");
}
else if (strcmp(argument, "derids") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "rIds");
}
else if (strcmp(argument, "desaddic") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "zaddIk");
}
else if (strcmp(argument, "desaddics") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "zaddIks");
}
else if (strcmp(argument, "descend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "sEnd");
}
else if (strcmp(argument, "descends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "sEnds");
}
else if (strcmp(argument, "deser") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "zEr");
}
else if (strcmp(argument, "desers") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "zErs");
}
else if (strcmp(argument, "desmemberment") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "smEmb" SMALL_E_DIAERESIS_IN_TEXT "rm" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "desmemberments") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "smEmb" SMALL_E_DIAERESIS_IN_TEXT "rm" SMALL_E_DIAERESIS_IN_TEXT "nts");
}
else if (strcmp(argument, "deten") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "tEn");
}
else if (strcmp(argument, "detens") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "d" SMALL_E_DIAERESIS_IN_TEXT "tEns");
}
else if (strcmp(argument, "differ") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dif(f)Er");
}
else if (strcmp(argument, "differs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dif(f)Ers");
}
else if (strcmp(argument, "diksdwinghend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "diksdwIng" SMALL_E_DIAERESIS_IN_TEXT "nd");
}
else if (strcmp(argument, "diksdwinghends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "diksdwIng" SMALL_E_DIAERESIS_IN_TEXT "nds");
}
else if (strcmp(argument, "direcs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dirEks");
}
else if (strcmp(argument, "direct") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dirEkt");
}
else if (strcmp(argument, "directs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dirEkts");
}
else if (strcmp(argument, "direg") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dirEg");
}
else if ((strcmp(argument, "DNA") == 0) || (strcmp(argument, "dna") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "de en a");
}
else if (strcmp(argument, "dusrig") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dusrIg");
}
else if (strcmp(argument, "dwinghend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dwIng" SMALL_E_DIAERESIS_IN_TEXT "nd");
}
else if (strcmp(argument, "dwinghends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dwIng" SMALL_E_DIAERESIS_IN_TEXT "nd");
}
else if (strcmp(argument, "document") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dok" CAPITAL_U_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "documents") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dok" CAPITAL_U_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nts");
}
else if (strcmp(argument, "ees") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "E" SMALL_E_DIAERESIS_IN_TEXT "s");
}
else if (strcmp(argument, "eet") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "E" SMALL_E_DIAERESIS_IN_TEXT "t");
}
else if (strcmp(argument, "elect") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "elEkt");
}
else if (strcmp(argument, "elecs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "elEks");
}
else if (strcmp(argument, "eleg") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "elEg");
}
else if (strcmp(argument, "emercs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "emErks");
}
else if (strcmp(argument, "emerg") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "emErg");
}
else if (strcmp(argument, "emolument") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "emol" CAPITAL_U_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "emoluments") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "emol" CAPITAL_U_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nts");
}
else if (strcmp(argument, "enderghend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "end" SMALL_E_DIAERESIS_IN_TEXT "rgEnd");
}
else if (strcmp(argument, "enderghends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "end" SMALL_E_DIAERESIS_IN_TEXT "rgEnds");
}
else if (strcmp(argument, "endermercs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "end" SMALL_E_DIAERESIS_IN_TEXT "rmErks");
}
else if (strcmp(argument, "endermerg") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "end" SMALL_E_DIAERESIS_IN_TEXT "rmErg");
}
else if (strcmp(argument, "endu") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "endU");
}
else if (strcmp(argument, "endus") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "endUs");
}
else if (strcmp(argument, "enebghir") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "En" SMALL_E_DIAERESIS_IN_TEXT "bgir");
}
else if (strcmp(argument, "engep") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "endjEp");
}
else if ((strcmp(argument, "England") == 0) || (strcmp(argument, "england") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "England");
}
else if (strcmp(argument, "engweu") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "engw" CAPITAL_O_DIAERESIS_IN_TEXT "");
}
else if (strcmp(argument, "engweus") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "engw" CAPITAL_O_DIAERESIS_IN_TEXT "s");
}
else if (strcmp(argument, "enkrew") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "enkrEw");
}
else if (strcmp(argument, "enkrews") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "enkrEws");
}
else if (strcmp(argument, "ensuite") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "enswIt");
}
else if (strcmp(argument, "ensuites") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "enswIts");
}
else if (strcmp(argument, "entretein") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "entr" SMALL_E_DIAERESIS_IN_TEXT "tEyn");
}
else if (strcmp(argument, "entreteins") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "entr" SMALL_E_DIAERESIS_IN_TEXT "tEyn");
}
else if (strcmp(argument, "establishment") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "estAblixm" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "etiwirt") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "etiwIrt");
}
else if (strcmp(argument, "excerpt") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ekstsErpt");
}
else if (strcmp(argument, "excerpts") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ekstsErpts");
}
else if (strcmp(argument, "exist") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "eksIst");
}
else if (strcmp(argument, "exists") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "eksIsts");
}
else if (strcmp(argument, "expremt") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "eksprEmt");
}
else if (strcmp(argument, "extend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ekstEnd");
}
else if (strcmp(argument, "extends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ekstEnds");
}
else if (strcmp(argument, "f") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ef");
}
else if (strcmp(argument, "forest") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "forEst");
}
else if (strcmp(argument, "forests") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "forEsts");
}
else if ((strcmp(argument, "FAQ") == 0) || (strcmp(argument, "faq") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ef a ku");
}
else if (strcmp(argument, "g") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dje");
}
else if (strcmp(argument, "h") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "hatc");
}
else if (strcmp(argument, "heresie") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "h" SMALL_E_DIAERESIS_IN_TEXT "r" SMALL_E_DIAERESIS_IN_TEXT "zI:");
}
else if (strcmp(argument, "indirect") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "indirEkt");
}
else if (strcmp(argument, "infer") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "infEr");
}
else if (strcmp(argument, "infers") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "infErs");
}
else if (strcmp(argument, "inser") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "insEr");
}
else if (strcmp(argument, "insers") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "insErs");
}
else if (strcmp(argument, "instrument") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "instr" CAPITAL_U_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "instruments") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "instr" CAPITAL_U_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nts");
}
else if (strcmp(argument, "interfer") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "int" SMALL_E_DIAERESIS_IN_TEXT "rfEr");
}
else if (strcmp(argument, "interfers") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "int" SMALL_E_DIAERESIS_IN_TEXT "rfErs");
}
else if (strcmp(argument, "internet") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "int" SMALL_E_DIAERESIS_IN_TEXT "rnEt");
}
else if (strcmp(argument, "internets") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "int" SMALL_E_DIAERESIS_IN_TEXT "rnEts");
}
else if (strcmp(argument, "interven") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "int" SMALL_E_DIAERESIS_IN_TEXT "rvEn");
}
else if (strcmp(argument, "intervens") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "int" SMALL_E_DIAERESIS_IN_TEXT "rvEns");
}
else if (strcmp(argument, "intervent") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "int" SMALL_E_DIAERESIS_IN_TEXT "rvEnt");
}
else if (strcmp(argument, "j") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "jye");
}
else if ((strcmp(argument, "Jeune-Tyrk") == 0) || (strcmp(argument, "jeune-tyrk") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "j" SMALL_O_DIAERESIS_IN_TEXT "n t" SMALL_U_DIAERESIS_IN_TEXT "rk");
}
else if (strcmp(argument, "k") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ka");
}
else if (strcmp(argument, "kaapstad") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kA:pstat");
}
else if (strcmp(argument, "kiwi") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kiwI");
}
else if (strcmp(argument, "kiwis") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "kiwIs");
}
else if (strcmp(argument, "Ku-Geong") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ku djeong");
}
else if (strcmp(argument, "l") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "el");
}
else if (strcmp(argument, "lineament") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "linEam" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "lineaments") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "linEam" SMALL_E_DIAERESIS_IN_TEXT "nts");
}
else if (strcmp(argument, "m") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "em");
}
else if (strcmp(argument, "menscenrect") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "mEns" SMALL_E_DIAERESIS_IN_TEXT "nr" SMALL_E_DIAERESIS_IN_TEXT "kt");
}
else if (strcmp(argument, "menscenrects") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "mEns" SMALL_E_DIAERESIS_IN_TEXT "nr" SMALL_E_DIAERESIS_IN_TEXT "kts");
}
else if (strcmp(argument, "ministernconcil") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "minIst" SMALL_E_DIAERESIS_IN_TEXT "rnkontsil");
}
else if (strcmp(argument, "ministernconcils") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "minIst" SMALL_E_DIAERESIS_IN_TEXT "rnkontsils");
}
else if (strcmp(argument, "n") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "en");
}
else if (strcmp(argument, "naudh") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "nAod");
}
else if (strcmp(argument, "naudhs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "nAods");
}
else if (strcmp(argument, "naut") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "nAot");
}
else if (strcmp(argument, "nauts") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "nAots");
}
else if (strcmp(argument, "negleg") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "n" SMALL_E_DIAERESIS_IN_TEXT "glEg");
}
else if (strcmp(argument, "neglecs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "n" SMALL_E_DIAERESIS_IN_TEXT "glEks");
}
else if (strcmp(argument, "niebtreb") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "nyebtrEb");
}
else if (strcmp(argument, "niebtrebs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "nyebtrEbs");
}
else if (strcmp(argument, "nilent") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "nilEnt");
}
else if (strcmp(argument, "nilents") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "nilEnts");
}
else if (strcmp(argument, "niscrib") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "niskrIb");
}
else if (strcmp(argument, "niscrips") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "niskrIps");
}
else if (strcmp(argument, "object") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "objEkt");
}
else if (strcmp(argument, "objects") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "objEkts");
}
else if (strcmp(argument, "obten") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "obtEn");
}
else if (strcmp(argument, "obtens") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "obtEns");
}
else if (strcmp(argument, "offend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ofEnd");
}
else if (strcmp(argument, "offends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ofEnds");
}
else if (strcmp(argument, "oiscrisc") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "oyskrIsk");
}
else if (strcmp(argument, "oiscriscs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "oyskrIsks");
}
else if (strcmp(argument, "oisdu") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "oysdU");
}
else if (strcmp(argument, "oisdus") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "oysdUs");
}
else if (strcmp(argument, "oisghend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "oysgEnd");
}
else if (strcmp(argument, "oisghends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "oysgEnds");
}
else if (strcmp(argument, "oiswind") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "oyswInd");
}
else if (strcmp(argument, "oiswinds") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "oyswInds");
}
else if (strcmp(argument, "ostend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ostEnd");
}
else if (strcmp(argument, "ostends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ostEnds");
}
else if (strcmp(argument, "p") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pe");
}
else if (strcmp(argument, "paris") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "parIs");
}
else if (strcmp(argument, "pehrnargument") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pe:rmarg" CAPITAL_U_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "pehrnarguments") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pe:rmarg" CAPITAL_U_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nts");
}
else if (strcmp(argument, "perhvdi") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pEr(h)vdi");
}
else if (strcmp(argument, "perigleg") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "p" SMALL_E_DIAERESIS_IN_TEXT "riglEg");
}
else if (strcmp(argument, "periglecs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "p" SMALL_E_DIAERESIS_IN_TEXT "riglEks");
}
else if (strcmp(argument, "peripuwen") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "p" SMALL_E_DIAERESIS_IN_TEXT "rip" CAPITAL_U_DIAERESIS_IN_TEXT "w" SMALL_E_DIAERESIS_IN_TEXT "n");
}
else if (strcmp(argument, "peripuwens") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "p" SMALL_E_DIAERESIS_IN_TEXT "rip" CAPITAL_U_DIAERESIS_IN_TEXT "w" SMALL_E_DIAERESIS_IN_TEXT "ns");
}
else if (strcmp(argument, "peristyl") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "p" SMALL_E_DIAERESIS_IN_TEXT "rist" CAPITAL_U_DIAERESIS_IN_TEXT "l");
}
else if (strcmp(argument, "peristyls") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "p" SMALL_E_DIAERESIS_IN_TEXT "rist" CAPITAL_U_DIAERESIS_IN_TEXT "ls");
}
else if (strcmp(argument, "perplex") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "p" SMALL_E_DIAERESIS_IN_TEXT "rplEks");
}
else if (strcmp(argument, "pipend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pipEnd");
}
else if (strcmp(argument, "pipends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pipEnds");
}
else if (strcmp(argument, "precept") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "tsEpt");
}
else if (strcmp(argument, "precepts") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "tsEpts");
}
else if (strcmp(argument, "precid") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "tsId");
}
else if (strcmp(argument, "precids") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "tsIdz");
}
else if (strcmp(argument, "precis") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "tsIs");
}
else if (strcmp(argument, "preemptive") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "Emptiv");
}
else if (strcmp(argument, "prefect") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "fEkt");
}
else if (strcmp(argument, "prefects") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "fEkts");
}
else if (strcmp(argument, "prefer") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "fEr");
}
else if (strcmp(argument, "prefers") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "fErs");
}
else if (strcmp(argument, "preghes") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "gEs");
}
else if (strcmp(argument, "presenning") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "zEnning");
}
else if (strcmp(argument, "presennings") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "zEnnings");
}
else if (strcmp(argument, "present") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "zEnt");
}
else if (strcmp(argument, "presents") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "zEnt");
}
else if (strcmp(argument, "pretend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "tEnd");
}
else if (strcmp(argument, "pretends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "tEnds");
}
else if (strcmp(argument, "preterit") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "preterIt");
}
else if (strcmp(argument, "preven") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "vEn");
}
else if (strcmp(argument, "prevens") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "vEns");
}
else if (strcmp(argument, "previd") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "vId");
}
else if (strcmp(argument, "previds") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "pr" SMALL_E_DIAERESIS_IN_TEXT "vIds");
}
else if (strcmp(argument, "probeprist") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "prObeprist");
}
else if (strcmp(argument, "probeprists") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "prObeprists");
}
else if (strcmp(argument, "procent") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "protsEnt");
}
else if (strcmp(argument, "procents") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "protsEnts");
}
else if (strcmp(argument, "projec") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "projEk");
}
else if (strcmp(argument, "projecs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "projEks");
}
else if (strcmp(argument, "project") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "projEkt");
}
else if (strcmp(argument, "projects") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "projEkts");
}
else if (strcmp(argument, "Prokrustes") == 0 || strcmp(argument, "prokrustes") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "prokrUst" SMALL_E_DIAERESIS_IN_TEXT "s");
}
else if (strcmp(argument, "prokwe") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "prOkw(" SMALL_E_DIAERESIS_IN_TEXT ")");
}
else if (strcmp(argument, "prophet") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "profEt");
}
else if (strcmp(argument, "prophets") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "profEts");
}
else if (strcmp(argument, "propos") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "propOs");
}
else if (strcmp(argument, "prospec") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "prospEk");
}
else if (strcmp(argument, "prospecs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "prospEks");
}
else if (strcmp(argument, "prospect") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "prospEkt");
}
else if (strcmp(argument, "prospects") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "prospEkts");
}
else if (strcmp(argument, "protecs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "protEks");
}
else if (strcmp(argument, "proteg") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "protEg");
}
else if (strcmp(argument, "protest") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "protEst");
}
else if (strcmp(argument, "protests") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "protEsts");
}
else if (strcmp(argument, "proverb") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "provErb");
}
else if (strcmp(argument, "proverbs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "provErbs");
}
else if (strcmp(argument, "provid") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "provId");
}
else if (strcmp(argument, "provids") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "provIds");
}
else if (strcmp(argument, "q") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ku");
}
else if (strcmp(argument, "r") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "er");
}
else if (strcmp(argument, "recent") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "tsEnt");
}
else if (strcmp(argument, "recep") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "tsEp");
}
else if (strcmp(argument, "receps") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "tsEps");
}
else if (strcmp(argument, "recept") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "tsEp");
}
else if (strcmp(argument, "recepts") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "tsEps");
}
else if (strcmp(argument, "recess") == 0 || strcmp(argument, "reccess") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "tsEs(s)");
}
else if (strcmp(argument, "record") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "kOrd");
}
else if (strcmp(argument, "recule") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "k" CAPITAL_U_DIAERESIS_IN_TEXT "l");
}
else if (strcmp(argument, "recules") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "k" CAPITAL_U_DIAERESIS_IN_TEXT "ls");
}
else if (strcmp(argument, "recurs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "kUrs");
}
else if (strcmp(argument, "recycling") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "ts" CAPITAL_U_DIAERESIS_IN_TEXT "kling");
}
else if (strcmp(argument, "regret") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "grEt");
}
else if (strcmp(argument, "regrets") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "grEts");
}
else if (strcmp(argument, "refer") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "fEr");
}
else if (strcmp(argument, "refers") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "fErs");
}
else if (strcmp(argument, "refert") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "fErt");
}
else if (strcmp(argument, "reflect") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "flEkt");
}
else if (strcmp(argument, "reflects") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "flEkts");
}
else if (strcmp(argument, "reflecs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "flEks");
}
else if (strcmp(argument, "refleg") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "flEg");
}
else if (strcmp(argument, "refreschment") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "frEcm" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "rejec") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "rejEk");
}
else if (strcmp(argument, "rejecs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "jEkt");
}
else if (strcmp(argument, "reject") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "jEkts");
}
else if (strcmp(argument, "relevant") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "l" SMALL_E_DIAERESIS_IN_TEXT "vAnt");
}
else if (strcmp(argument, "remix") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "mIks");
}
else if (strcmp(argument, "reoinascen") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "oynAs" SMALL_E_DIAERESIS_IN_TEXT "n");
}
else if (strcmp(argument, "reoinascens") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "oynAs" SMALL_E_DIAERESIS_IN_TEXT "ns");
}
else if (strcmp(argument, "reper") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "pEr");
}
else if (strcmp(argument, "repers") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "pErs");
}
else if (strcmp(argument, "resid") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "zId");
}
else if (strcmp(argument, "resids") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "zIds");
}
else if (strcmp(argument, "respect") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "spEkt");
}
else if (strcmp(argument, "respects") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "spEkts");
}
else if (strcmp(argument, "restrict") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "strIkt");
}
else if (strcmp(argument, "restricts") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "strIkts");
}
else if (strcmp(argument, "revers") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "vErs");
}
else if (strcmp(argument, "rewaldh") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "wAld");
}
else if (strcmp(argument, "rewaldhs") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "wAlds");
}
else if (strcmp(argument, "rewidue") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "wid" CAPITAL_U_DIAERESIS_IN_TEXT ":");
}
else if (strcmp(argument, "rewidues") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "wid" CAPITAL_U_DIAERESIS_IN_TEXT ":s");
}
else if (strcmp(argument, "rewiduesa") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "wid" CAPITAL_U_DIAERESIS_IN_TEXT ":za");
}
else if (strcmp(argument, "rewiduesas") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "wid" CAPITAL_U_DIAERESIS_IN_TEXT ":zas");
}
else if (strcmp(argument, "rewost") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "wOst");
}
else if (strcmp(argument, "rewoswakt") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "wozwAkt");
}
else if (strcmp(argument, "rewoswakts") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "wozwAkts");
}
else if (strcmp(argument, "rewot") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "wOt");
}
else if (strcmp(argument, "rewots") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "r" SMALL_E_DIAERESIS_IN_TEXT "wOts");
}
else if ((strcmp(argument, "RNA") == 0) || (strcmp(argument, "rna") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "er en a");
}
else if (strcmp(argument, "s") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "es");
}
else if ((strcmp(argument, "SARS") == 0) || (strcmp(argument, "sars") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "es a er es");
}
else if (strcmp(argument, "secret") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "s" SMALL_E_DIAERESIS_IN_TEXT "krEt");
}
else if (strcmp(argument, "secrets") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "s" SMALL_E_DIAERESIS_IN_TEXT "krEts");
}
else if (strcmp(argument, "seloswent") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "sElosw" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "suaodent") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "swaOd" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "suapit") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "swapIt");
}
else if (strcmp(argument, "subven") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "subvEn");
}
else if (strcmp(argument, "subvens") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "subvEns");
}
else if (strcmp(argument, "suspend") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "suspEnd");
}
else if (strcmp(argument, "suspends") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "suspEnds");
}
else if (strcmp(argument, "suggest") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "sugdjEst");
}
else if (strcmp(argument, "suggests") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "sugdjEsts");
}
else if (strcmp(argument, "t") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "te");
}
else if (strcmp(argument, "traitement") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "tr" CAPITAL_A_DIAERESIS_IN_TEXT "t" SMALL_E_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nt");
}
else if (strcmp(argument, "traitements") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "tr" CAPITAL_A_DIAERESIS_IN_TEXT "t" SMALL_E_DIAERESIS_IN_TEXT "m" SMALL_E_DIAERESIS_IN_TEXT "nts");
}
else if (strcmp(argument, "transfer") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "transfEr");
}
else if (strcmp(argument, "transfers") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "transfErs");
}
else if (strcmp(argument, "transcrib") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "transkrIb");
}
else if (strcmp(argument, "transcrips") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "transkrIps");
}
else if ((strcmp(argument, "TV") == 0) || (strcmp(argument, "tv") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "te ve");
}
else if (strcmp(argument, "v") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ve");
}
else if ((strcmp(argument, "VHS") == 0) || (strcmp(argument, "vhs") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "ve hatc es");
}
else if (strcmp(argument, "vinyek") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "vIny" SMALL_E_DIAERESIS_IN_TEXT "k");
}
else if (strcmp(argument, "virgenvinyek") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "virdj" SMALL_E_DIAERESIS_IN_TEXT "nvIny" SMALL_E_DIAERESIS_IN_TEXT "k");
}
else if (strcmp(argument, "virgenvinyeks") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "virdj" SMALL_E_DIAERESIS_IN_TEXT "nvIny" SMALL_E_DIAERESIS_IN_TEXT "ks");
}
else if (strcmp(argument, "w") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "we");
}
else if ((strcmp(argument, "WC") == 0) || (strcmp(argument, "wc") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "we tse");
}
else if (strcmp(argument, "x") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "iks");
}
else if ((strcmp(argument, "X-rai") == 0) || (strcmp(argument, "x-rai") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "iks rä");
}
else if (strcmp(argument, "y") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, SMALL_U_DIAERESIS_IN_TEXT);
}
else if (strcmp(argument, "yoinkjiae") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "yoynkjiAy");
}
else if (strcmp(argument, "yoinkjiaes") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "yoynkjiAys");
}
else if (strcmp(argument, "yui") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "yuI");
}
else if (strcmp(argument, "z") == 0)
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dzed");
}
else if ((strcmp(argument, "Zakynthos") == 0) || (strcmp(argument, "zakynthos") == 0))
{
	if (show_system_messages) printf("\npoint ready_made_solution\n");
	strcpy(SPT_word, "dzak" CAPITAL_U_DIAERESIS_IN_TEXT "n" SECTION_SIGN_IN_TEXT "os");
}
